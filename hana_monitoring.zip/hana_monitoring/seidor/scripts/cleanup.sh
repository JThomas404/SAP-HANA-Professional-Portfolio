#!/bin/bash
folder_path="/seidor/monitoring/"

cd "$folder_path"
find . -name "*.xml" -type f -mtime +30 -delete
logger -t cleanup.sh "Seidor Networks - Deleted XML log files older than 30 days in $folder_path"
echo "Log files older than 30 days have been deleted"
