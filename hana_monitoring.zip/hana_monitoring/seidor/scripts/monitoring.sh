#!/bin/bash
#
# This script will run all stored procedures specified in the hana_procs_to_run file and export the results to the EXPORT_DIR directory in XML format
# Remember to update HANA_HOST and HDBCLIENT variables
#
# Variables to set
HANA_HOST=                              # This is the IP or FQDN of the HANA server
HANA_PORT="30015"                                   # This is the port that HANA listens on
HANA_SCHEMA="SYSTEM"                                # This is the HANA schema that the stored procedures are saved in
HDBCLIENT=       # This is the full path to the hdbsql command
SEIDOR_DIR="/seidor"                                # This is the root path where everything is saved
EXPORT_DIR="$SEIDOR_DIR/monitoring"                 # This is the path where the exported xml files will be saved
SCRIPTS_DIR="$SEIDOR_DIR/scripts"                   # This is where the scripts are saved
CREDENTIALS_FILE="$SCRIPTS_DIR/hana.conf"           # This is the file that contains the credentials to connect to the HANA instance
PROCS_TO_RUN="$SCRIPTS_DIR/hana_procs_to_run.txt"   # This is the file that contains the list of stored procedures to run
XML_HEADER='<?xml version="1.0" encoding="UTF-8"?>' # This is the standard XML header
#
# Display the selected variables on each run
echo "The hdbsql selected is $HDBCLIENT"
echo "The HANA host is $HANA_HOST:$HANA_PORT"
echo "The Seidor directory is $SEIDOR_DIR"
echo "The export directory is $EXPORT_DIR"
echo "The scripts directory is $SCRIPTS_DIR"
#
# Create the required directories if they don't exist
mkdir -p "$SEIDOR_DIR" -m 777
mkdir -p "$EXPORT_DIR" -m 777
mkdir -p "$SCRIPTS_DIR" -m 777
#
# Read the HANA username and password from the configuration file
HANA_USER=$(awk -F= '/\[HANA\]/{a=1} a==1&&$1~/^USER/{print $2;exit}' "$CREDENTIALS_FILE")
HANA_PASSWORD=$(awk -F= '/\[HANA\]/{a=1} a==1&&$1~/^PASSWORD/{print $2;exit}' "$CREDENTIALS_FILE")
#
# Loop through the PROCS_TO_RUN file and run each proc specified
while IFS= read -r PROC_NAME; do
    # Skip empty lines
    if [ -z "$PROC_NAME" ]; then
        continue
    fi
    # Run the stored procedure and save the results as an XML file
    TIMESTAMP=$(date '+%Y%m%d_%H%M')
    OUTPUT_FILE="$EXPORT_DIR/${PROC_NAME}_${TIMESTAMP}.xml"
    TEMP_FILE="$EXPORT_DIR/temp.xml"
    $HDBCLIENT -n $HANA_HOST:$HANA_PORT -u "$HANA_USER" -p "$HANA_PASSWORD" -m -xml -x -xml -nochop -a -b all \
        "CALL $HANA_SCHEMA.$PROC_NAME" | awk '{gsub(/\\n/, ""); gsub(/\\/, ""); print}' | sed '1s/^"//; $s/"$//' > "$TEMP_FILE"
    echo $XML_HEADER > "$OUTPUT_FILE"
    cat "$TEMP_FILE" >> "$OUTPUT_FILE"
    rm "$TEMP_FILE"
    echo "Query results for $PROC_NAME saved as $OUTPUT_FILE"
    # Log the details to the system log, usually /var/log/messages or /var/log/syslog
    # Read these details with the command: grep 'seidor_monitoring' /var/log/messages
    logger -t "seidor_monitoring" "Stored procedure $PROC_NAME has been executed and the results exported to $OUTPUT_FILE"
done <"$PROCS_TO_RUN"
