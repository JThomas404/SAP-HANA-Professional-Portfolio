CREATE PROCEDURE "SYSTEM"."SN_SP_FP_VERSION"
AS
BEGIN
SELECT "Version" AS "SAP_Version" 
      ,"FP" AS "Feature_Pack"
      ,"BuildDesc" AS "Build_Description"
FROM "SBOCOMMON"."SINF"
FOR XML;
END;