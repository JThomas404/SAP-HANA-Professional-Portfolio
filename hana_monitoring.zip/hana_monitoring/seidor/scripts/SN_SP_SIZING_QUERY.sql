CREATE PROCEDURE "SYSTEM"."SN_SP_SIZING_QUERY" LANGUAGE SQLScript
AS
BEGIN
    DECLARE num_of_schema DOUBLE;
    DECLARE header_count DOUBLE;
    DECLARE line_count DOUBLE;
    DECLARE initial_memory DOUBLE = 32;
    DECLARE concurrent_users INT;
    DECLARE schema_memory DOUBLE;
    DECLARE data_memory DOUBLE;
    DECLARE max_memory DOUBLE;
    DECLARE CURSOR curs1
    FOR

    SELECT schema_name
        , table_name
    FROM PUBLIC.tables
    WHERE SCHEMA_NAME IN (
            SELECT schema_name
            FROM PUBLIC.TABLES
            WHERE TABLE_NAME = 'CINF'
            )
        AND table_name IN (
            'OINV'
            , 'ORDR'
            , 'OQUT'
            , 'ODLN'
            , 'OPCH'
            , 'OPDN'
            , 'OPOR'
            , 'ORCT'
            , 'OVPM'
            , 'OIGE'
            , 'OIGN'
            , 'OWTR'
            , 'INV1'
            , 'RDR1'
            , 'QUT1'
            , 'DLN1'
            , 'PCH1'
            , 'PDN1'
            , 'POR1'
            , 'RCT2'
            , 'VPM2'
            , 'IGE1'
            , 'IGN1'
            , 'WTR1'
            );
    FOR

    cur_row AS curs1() do

    EXEC 'load "' || cur_row.SCHEMA_NAME || '"."' || cur_row.TABLE_NAME || '" 
all';
END
FOR;

SELECT COUNT('A')
INTO concurrent_users
FROM M_CONNECTIONS
WHERE CONNECTION_ID > 0
    AND CURRENT_SCHEMA_NAME IN (
        SELECT SCHEMA_NAME
        FROM M_CS_TABLES
        WHERE TABLE_NAME = 'CINF'
        );

SELECT COUNT(TABLE_NAME)
INTO num_of_schema
FROM M_CS_TABLES
WHERE TABLE_NAME = 'CINF';

schema_memory = :num_of_schema * 4;

SELECT IFNULL(SUM(RECORD_COUNT), 0)
INTO header_count
FROM M_CS_TABLES
WHERE TABLE_NAME IN (
        'OINV'
        , 'ORDR'
        , 'OQUT'
        , 'ODLN'
        , 'OPCH'
        , 'OPDN'
        , 'OPOR'
        , 'ORCT'
        , 'OVPM'
        , 'OIGE'
        , 'OIGN'
        , 'OWTR'
        );

SELECT IFNULL(SUM(RECORD_COUNT), 0)
INTO line_count
FROM M_CS_TABLES
WHERE TABLE_NAME IN (
        'INV1'
        , 'RDR1'
        , 'QUT1'
        , 'DLN1'
        , 'PCH1'
        , 'PDN1'
        , 'POR1'
        , 'RCT2'
        , 'VPM2'
        , 'IGE1'
        , 'IGN1'
        , 'WTR1'
        );

IF header_count > 0
    AND line_count > 0 THEN data_memory = :header_count * 2 / 300 / 1024 + :line_count / 300 / 1024;ELSE
    data_memory = 0;
    END

IF ;
    IF :schema_memory > :data_memory THEN max_memory = :schema_memory;ELSE
        max_memory = :data_memory;
    END

IF ;
    WITH "Table400"
    AS (
        SELECT HOST
            , round((USED_PHYSICAL_MEMORY + FREE_PHYSICAL_MEMORY) / (1024 * 1024 * 1024), 3) AS "PhysicalMemory"
            , round(USED_PHYSICAL_MEMORY / (1024 * 1024 * 1024), 3) AS "ResidentMemory"
        FROM PUBLIC.M_HOST_RESOURCE_UTILIZATION
        )
    SELECT CURRENT_TIMESTAMP "TimeStamp"
        , round(:max_memory + :initial_memory + :concurrent_users * 0.15 / 2, 2) AS "ReqMemGB"
        , :num_of_schema AS "NumSchema"
        , :header_count AS "NumDocs"
        , CASE 
            WHEN :header_count > 0
                THEN round(:line_count / :header_count, 2)
            ELSE 0
            END AS "DocAvgLines"
        , :concurrent_users AS "CompanyDBCon"
        , HOST "Host"
        , "PhysicalMemory" "PhysMemGB"
        , "ResidentMemory" "ResMemGB"
    FROM DUMMY
    CROSS JOIN "Table400"
    FOR XML;
    END;
