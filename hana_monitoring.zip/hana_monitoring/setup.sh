#!/bin/bash
# Created by ajvanjaarsveld@seidornetworks.com 2025/02/28

# Create the directory structure
cp -R seidor /

# Obtain HANA SYSTEM password from user
echo "Enter the HANA SYSTEM user password:"
read user_input

# Update the password value in the hana.conf file based on user input
sed -i 's/PASSWORD=/PASSWORD='$user_input'/g' /seidor/scripts/hana.conf
echo "SYSTEM user password updated"

# Obtain the local IPv4 address of the host
ip_address=$(/sbin/ip -o -4 addr list eth0 | awk '{print $4}' | cut -d/ -f1)

# Update the HANA_HOST variable
sed -i 's/HANA_HOST=/HANA_HOST="'"$ip_address"'"/g' /seidor/scripts/monitoring.sh
echo "The local IPv4 address is $ip_address"

# Obtain the path of the hdbsql executable
search_output=$(find /hana/shared /usr/sap -name "hdbclient")

if [ $search_output=*"/hana/shared/"* ]
then
       hdbsql_path=$search_output"/hdbsql"
else
       hdbsql_path="/usr/sap/hdbclient/hdbsql"
fi

# Update the HDBCLIENT variable
sed -i 's%HDBCLIENT=%HDBCLIENT="'"$hdbsql_path"'"%g' /seidor/scripts/monitoring.sh
echo "The path to the hdbsql executable is "$hdbsql_path

# Share the /seidor/monitoring log output directory: If already shared, do nothing. If not yet shared; update the smb.conf file
smb_path=/etc/samba/smb.conf

if grep -q monitoring $smb_path
then 
	echo "Log output directory already shared"
else
	echo -e "[monitoring]" >> $smb_path
	echo -e "        path = /seidor/monitoring" >> $smb_path
	echo -e "        writeable = yes" >> $smb_path
	echo -e "        browseable = yes" >> $smb_path
	echo -e "        guest ok = yes" >> $smb_path
	echo -e "        read only = no" >> $smb_path
	echo "Log output directory shared"
fi

# Restart the SMB service
systemctl restart smb

# Add the executable permission to all shell scripts
chmod +x /seidor/scripts/monitoring.sh
chmod +x /seidor/scripts/cleanup.sh

# Remove the delete_old_logs.sh script if it already exists so that only cleanup.sh remains
if test -e /seidor/scripts/delete_old_logs.sh; then
	rm -rf /seidor/scripts/delete_old_logs.sh
fi

if test -e /etc/cron.daily/delete_old_logs; then
	rm -rf /etc/cron.daily/delete_old_logs
fi

# Create cron jobs: 
# If a cron job already exists for monitoring.sh, leave it as it
# If a cron job exists for delete_old_logs.sh, replace it with cleanup.sh
# Else, create the cron jobs if neither cron jobs exist
crontab_file=/var/spool/cron/tabs/root

if grep -q 'monitoring.sh\|delete_old_logs.sh' $crontab_file; then
	echo "Cron job already exists for /seidor/scripts/monitoring.sh"
	sed -i 's/delete_old_logs.sh/cleanup.sh/g' $crontab_file
	(crontab -l 2>/dev/null; echo "@weekly /seidor/scripts/cleanup.sh") | crontab -
	echo "Cron job created for /seidor/scripts/cleanup.sh"
else
	(crontab -l 2>/dev/null; echo "@hourly /seidor/scripts/monitoring.sh") | crontab -
	(crontab -l 2>/dev/null; echo "@weekly /seidor/scripts/cleanup.sh") | crontab -
	echo "Cron jobs created"
fi

# Change the permissions of the hana.conf file to read only for root
chmod 600 /seidor/scripts/hana.conf

echo "All tasks completed successfully"
